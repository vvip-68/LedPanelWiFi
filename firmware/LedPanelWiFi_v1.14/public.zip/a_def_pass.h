// ------------- WiFi & MQTT parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "your-SSID"                    // Имя WiFi сети
#define NETWORK_PASS "your-password"                // Пароль для подключения к WiFi сети

// Для управления и отладки можно использовать одну из следующих консолей: client.mqtt.4api.ru, hivemq.com/demos/websocket-client

#undef  DEFAULT_MQTT_SERVER
#undef  DEFAULT_MQTT_USER
#undef  DEFAULT_MQTT_PASS
#undef  DEFAULT_MQTT_PORT
#undef  DEFAULT_MQTT_PREFIX

#define DEFAULT_MQTT_SERVER   "mqtt.by"             // MQTT сервер по умолчанию
#define DEFAULT_MQTT_USER     "user"                // Имя mqtt-пользователя по умолчанию 
#define DEFAULT_MQTT_PASS     "grl284ks"            // Пароль mqtt-пользователя по умолчанию
#define DEFAULT_MQTT_PORT     1883                  // Порт mqtt-соединения TCP по умолчанию

// API-идентификатор сервиса получения погоды
#undef  WEATHER_API_KEY
#define WEATHER_API_KEY "553cfcc9ac3fa47794e1fb936fe66fd8" // "6a4ba421859c9f4166697758b68d889b"

#if (DEVICE_ID == 0)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d60"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d30"            // Префикс топика сообщения устройств DEVICE_ID == 0 на ESP32
#endif
#endif

#if (DEVICE_ID == 1)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d61"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d31"            // Префикс топика сообщения устройств DEVICE_ID == 1 на ESP32
#endif
#endif

#if (DEVICE_ID == 2)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d62"            // Префикс топика сообщения устройств DEVICE_ID == 2 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d32"            // Префикс топика сообщения устройств DEVICE_ID == 2 на ESP32
#endif
#endif

#if (DEVICE_ID == 3)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d63"            // Префикс топика сообщения устройств DEVICE_ID == 3 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d33"            // Префикс топика сообщения устройств DEVICE_ID == 3 на ESP32
#endif
#endif

#if (DEVICE_ID == 4)
#if defined(ESP8266)  
#define DEFAULT_MQTT_PREFIX   "b7256d64"            // Префикс топика сообщения устройств DEVICE_ID == 4 на ESP8266
#endif
#if defined(ESP32)  
#define DEFAULT_MQTT_PREFIX   "b7256d34"            // Префикс топика сообщения устройств DEVICE_ID == 4 на ESP32
#endif
#endif
