// ------------- WiFi parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "Your SSID"    // Имя WiFi сети
#define NETWORK_PASS "Your PASS"    // Пароль для подключения к WiFi сети 

// API-идентификатор сервиса получения погоды
#undef  WEATHER_API_KEY
#define WEATHER_API_KEY "6a4ba421859c9f4166697758b68d889b" // "553cfcc9ac3fa47794e1fb936fe66fd8"
