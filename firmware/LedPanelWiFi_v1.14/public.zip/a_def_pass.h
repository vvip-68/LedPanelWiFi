// ------------- WiFi parameters --------------
#undef  NETWORK_SSID
#undef  NETWORK_PASS

#define NETWORK_SSID "your-ssid"                      // Имя WiFi сети
#define NETWORK_PASS "your-pass"                      // Пароль для подключения к WiFi сети 

// API-идентификатор сервиса получения погоды OpemWeatherMap
#undef  OWM_WEATHER_API_KEY
#define OWM_WEATHER_API_KEY F("6a4ba421859c9f4166697758b68d889b")

